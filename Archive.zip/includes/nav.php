    <div class="row">
    <nav class="top-bar">
    <section id="section-wrapper">
    <ul id="navigation" class="left nav-cover">
    <!--
	<li id="mobile_menu" class="has-dropdown">
	<a id="mobile_header" href="#"><img src="images/img/bars.jpg" /></a>
	<ul id="mobile_dropdown" class="dropdown">
    -->

        <!-- #menu-item-one -->
		<li id="home" class="has-dropdown"><a class="change-hover no-active" href="index.php">Home</a></li>   
        <!-- #menu-item-two -->
        <li id="about" class="has-dropdown">
        <a href="about.php">About</a>
            <ul class="dropdown">
                <li><a href="about.php">About RU Health</a></li>
                <li><a href="#">Dropdown</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-three -->
        <li id="academics" class="has-dropdown">
        <a href="academics.php">Academics</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-four -->
        <li id="admissions" class="has-dropdown">
        <a href="admissions.php">Admissions</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-five -->
        <li id="care" class="has-dropdown">
        <a href="care.php">Patient Care</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-six -->
        <li id="news" class="has-dropdown">
        <a href="news.php">News</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-seven -->
        <li id="research" class="has-dropdown">
        <a href="research.php">Research</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
        <!-- #menu-item-eight -->
        <li id="information" class="has-dropdown">
        <a href="information.php">Information For</a>
            <ul class="dropdown">
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
                <li><a href="#">Dropdown Option</a></li>
            </ul>
        </li>
    <!--
    </ul>
    </li>
    -->
    </ul>
    </section>
    </nav>
    </div>
