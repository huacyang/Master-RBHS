<div class="row">
    <div id="top">   
    <div id="hleft">
        <ul>
            <li class="first"><a href="http://www.rutgers.edu">Rutgers Home</a></li>
            <li><a href="http://www.nb.rutgers.edu">New Brunswick</a></li>
            <li><a href="http://www.newark.rutgers.edu">Newark</a></li>
            <li class="last"><a href="http://www.camden.rutgers.edu">Camden</a></li>
        </ul>
    </div>
    <div id="hright">
    University search
    </div>
	</div>

   <div id="masthead">
         <!--<a href="index.php" id="logo"><img src="includes/img/logo.gif" alt="Rutgers" title="Rutgers" width="168" height="47" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#" id="site-name">Biomedical and Health Sciences</a>-->
    </div>
</div>
