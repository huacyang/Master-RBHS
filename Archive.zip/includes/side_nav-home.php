<div id="side_bar-home" class="three pull-nine mobile-four columns padding">
<div class="row">
	<!-- First Section -->
    <div class="ten mobile-four columns end padding">
    <h2 class="title">Quick Links</h2>
        <ul class="bullets-green">
            <li><a href="#">Sea Decore Omnium</a></li>
            <li><a href="#">Ei Quando Numquam</a></li>
            <li><a href="#">Vel Tota Fugit</a></li>
            <li><a href="#">Interpretaris</a></li>
            <li><a href="#">Vivendum Menandri</a></li>
            <li><a href="#">Choro Discere</a></li>
        </ul>
	</div>
    <!-- Second Section -->
    <div class="ten mobile-four columns end padding socialmedia">
    <h2 class="title">Follow Us</h2>
        <ul>
            <li><a href="#"><img src="includes/img/facebook.jpg" />Facebook</a></li>
            <li><a href="#"><img src="includes/img/twitter.jpg" />Twitter</a></li>
        </ul>
	</div>
</div>
</div>