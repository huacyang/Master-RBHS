<div id="side_bar-home" class="three pull-nine mobile-four columns padding">
<div class="row">
	<!-- First Section -->
    <div class="twelve mobile-four columns padding">
    <h1 class="title">Quick Links</h1><hr/>
        <ul class="bullets-green">
            <li><a href="#">Sea Decore Omnium</a></li>
            <li><a href="#">Ei Quando Numquam</a></li>
            <li><a href="#">Vel Tota Fugit</a></li>
            <li><a href="#">Interpretaris</a></li>
            <li><a href="#">Vivendum Menandri</a></li>
            <li><a href="#">Choro Discere</a></li>
        </ul>
	</div>
    <!-- Second Section -->
    <div class="twelve mobile-four columns padding">
    <h1 class="title">Follow Us</h1><hr/>
        <ul>
            <li class="facebook"><a href="#">Facebook</a></li>
            <li class="twitter"><a href="#">Twitter</a></li>
        </ul>
	</div>
</div>
</div>