<div id="side_nav" class="three pull-nine mobile-four columns"><br/>
	<div class="wrapper">
    <!-- First Section -->
    <h2>About RBHS</h2>
    <div class="row">
        <div class="twelve columns">
        <ul class="nav-bar vertical bg-white small">
            <li><a href="about.php">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">Diversity Advantage</a></li>
            <li><a href="#">Frequently Asked Questions</a></li>
        </ul>
        </div>
	</div>
    <!-- Second Section -->
    <div class="panel bg-white padding">
    <h2>Related</h2>
    <div class="row">
        <div class="twelve columns item-list">
        <ul>
            <li><a href="#">Before You Apply</a></li>
            <li><a href="#">Application Guidelines</a></li>
            <li><a href="#">Supporting Materials</a></li>
            <li><a href="#">Check your Status</a></li>
            <li><a href="#">What's Next?</a></li>
        </ul>
        </div>
    </div>
	</div>
    </div>
</div>