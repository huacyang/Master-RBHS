<div id="side_nav" class="three pull-nine mobile-four columns"><br/>
	<div class="wrapper">
    <!-- First Section -->
    <h2>Academics</h2>
    <div class="row">
        <div class="twelve columns sidenav-shift">
        <ul class="nav-bar vertical small">
            <li id="sb_academics"><a href="academics.php">Academics Overview</a></li>
            <li id="sb_schools"><a href="schools.php">Schools</a></li>
            <li id="sb_continuing"><a href="continuing.php">Continuing Education</a></li>
            <li id="sb_online"><a href="online.php">Online Education</a></li>
            <li id="sb_graduate_med"><a href="graduate_med.php">Grad Medical Education</a></li>
            <li id="sb_graduate"><a href="graduate.php">Graduate Education</a></li>
            <li id="sb_undergraduate"><a href="undergraduate.php">Undergraduate Education</a></li>
        </ul>
        </div>
	</div>
    