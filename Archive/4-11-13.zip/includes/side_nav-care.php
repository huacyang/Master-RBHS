<div id="side_nav" class="three pull-nine mobile-four columns"><br/>
	<div class="wrapper">
    <!-- First Section -->
    <h2>Patient Care</h2>
    <div class="row">
        <div class="twelve columns sidenav-shift">
        <ul class="nav-bar vertical small">
            <li><a href="about.php">Patient Care</a></li>
            <li><a href="reference.php">Physicians Reference Services</a></li>
            <li><a href="community.php">Community Health</a></li>
            <li><a href="practices.php">Clinical Practices</a></li>
            <li><a href="trials.php">Clinical Trials</a></li>
        </ul>
        </div>
	</div>
   