<div id="side_nav" class="three pull-nine mobile-four columns"><br/>
	<div class="wrapper">
    <!-- First Section -->
    <h2>Research</h2>
    <div class="row">
        <div class="twelve columns sidenav-shift">
        <ul class="nav-bar vertical small">
            <li><a href="research.php">Research Overview</a></li>
            <li><a href="institutes.php">Institutes</a></li>
            <li><a href="research_org.php">Clinical Research Orgs</a></li>
        </ul>
        </div>
	</div>
   