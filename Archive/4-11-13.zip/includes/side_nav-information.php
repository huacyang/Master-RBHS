<div id="side_nav" class="three pull-nine mobile-four columns"><br/>
	<div class="wrapper">
    <!-- First Section -->
    <h2>Information</h2>
    <div class="row">
        <div class="twelve columns sidenav-shift">
        <ul class="nav-bar vertical small">
            <li><a href="information_prospective.php">Prospective Students</a></li>
            <li><a href="information_current.php">Current Students</a></li>
            <li><a href="information_patients.php">Patients</a></li>
            <li><a href="information_faculty_staff.php">Faculty/Staff</a></li>
            <li><a href="information_alumni.php">Alumni</a></li>
            <li><a href="information_donors.php">Donors</a></li>
        </ul>
        </div>
	</div>
   