<div id="header" class="row">
    <div id="top">   
    <div id="hleft">
        <ul class="shift-header">
            <li class="first"><a href="http://www.rutgers.edu">Rutgers Home</a></li>
            <li><a href="http://www.nb.rutgers.edu">New Brunswick</a></li>
            <li><a href="http://www.newark.rutgers.edu">Newark</a></li>
            <li class="last"><a href="http://www.camden.rutgers.edu">Camden</a></li>
        	<div id="WHYie"></div>
            <div id="NOTie"></div>
        </ul>
    </div>
    <div id="hright">
		<a href="http://search.rutgers.edu" target="_blank">University Search</a>
    </div>
	</div>

   <div id="masthead"><img src="http://www.rutgers.edu/sites/www.rutgers.edu/themes/core_base/images/clear.gif" style="width:26%;height:100%;"></div>
</div>
