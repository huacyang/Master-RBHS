<footer>
<div class="twelve columns ">
<p class="copy"><a href="http://www.rutgers.edu/site-resource/copyright-information">Copyright &copy;2013</a>, Rutgers, The State University of New Jersey, an equal opportunity, affirmative action institution.
</p>
</div>
</footer>
